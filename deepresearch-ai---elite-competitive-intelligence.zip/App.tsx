
import React, { useState, useRef, useEffect } from 'react';
import { performDeepScan, getLiveNews, getTacticalRebuttals } from './geminiService';
import { Scanner } from './components/Scanner';
import { ResultsView } from './components/ResultsView';
import { LoadingOverlay } from './components/LoadingOverlay';
import { RoadmapView } from './components/RoadmapView';
import { Modal } from './components/Modal';
import { ResearchResult, ScanStatus, NewsItem, TacticalRebuttal, User } from './types';
import { isValidCode, verifyLicenseAPI } from './mockCodes';
import { 
  AlertCircle, RefreshCw, Search, Shield, Zap, Globe, 
  Download, Mail, Target, Sparkles, TrendingUp,
  Linkedin, Twitter, ChevronDown, LogOut, CreditCard,
  Map, Play, Loader2, Info, ExternalLink, ChevronLeft, HelpCircle, Book,
  Check, Briefcase, Ticket, ShoppingCart, Lock, Key, Star, ArrowRight, PartyPopper,
  ShieldCheck, Layout, MessageCircle, Bug, Copy, HelpCircle as SupportIcon
} from 'lucide-react';

type ActiveModal = 'none' | 'pricing' | 'api' | 'signin' | 'support' | 'privacy' | 'terms' | 'about' | 'cheat-sheet' | 'live-content' | 'battlecard' | 'license-verify' | 'checkout-success';
type ActiveView = 'landing' | 'dashboard' | 'roadmap';

// Standard Lemon Squeezy Variant-based URL
const LS_VARIANT_ID = '8e6c4333-e578-4f81-9f2d-74d3d237937e'; 
const LEMON_SQUEEZY_BASE_URL = 'https://deepresearch.lemonsqueezy.com/buy';
const LS_CHECKOUT_URL = `${LEMON_SQUEEZY_BASE_URL}/${LS_VARIANT_ID}?embed=0&test_mode=1`; 
const SUPPORT_EMAIL = 'support@deepresearch.ai';

const App: React.FC = () => {
  // Global State
  const [activeView, setActiveView] = useState<ActiveView>('landing');
  const [status, setStatus] = useState<ScanStatus>('idle');
  const [result, setResult] = useState<ResearchResult | null>(null);
  const [targetUrl, setTargetUrl] = useState('');
  const [homeUrl, setHomeUrl] = useState('');
  const [industry, setIndustry] = useState('SaaS / Software');
  
  // UI Modal State
  const [activeModal, setActiveModal] = useState<ActiveModal>('none');
  const [showCheckoutDebug, setShowCheckoutDebug] = useState(false);
  
  // App Logic State
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [redeemCode, setRedeemCode] = useState('');
  const [isVerifyingLicense, setIsVerifyingLicense] = useState(false);
  
  // Loading States
  const [isNewsLoading, setIsNewsLoading] = useState(false);
  const [isKillScriptsLoading, setIsKillScriptsLoading] = useState(false);
  const [isBattlecardLoading, setIsBattlecardLoading] = useState(false);
  const [newsResults, setNewsResults] = useState<NewsItem[] | null>(null);
  const [tacticalRebuttals, setTacticalRebuttals] = useState<TacticalRebuttal[] | null>(null);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // License verification on app start
  useEffect(() => {
    const checkLicenseOnStart = async () => {
      const savedKey = localStorage.getItem('DR_LICENSE_KEY');
      
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('checkout') === 'success' || urlParams.get('payment_success') === 'true') {
        setActiveModal('checkout-success');
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      if (savedKey) {
        setIsVerifyingLicense(true);
        const isValid = await verifyLicenseAPI(savedKey);
        setIsVerifyingLicense(false);
        
        setUser({
          name: 'Elite User',
          credits: isValid ? 'Unlimited' : 0,
          tier: isValid ? 'Lifetime Pro' : 'Standard',
          isSubscribed: isValid,
          licenseKey: savedKey
        });
        if (isValid) setActiveView('dashboard');
      } else {
        setUser({
          name: 'Scholar',
          credits: 0,
          tier: 'Standard',
          isSubscribed: false
        });
      }
    };

    checkLicenseOnStart();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowProfileDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const validateUrls = () => {
    if (!targetUrl.trim() || !homeUrl.trim()) {
      setError("Please provide both Your URL and a Competitor URL first.");
      return false;
    }
    setError(null);
    return true;
  };

  const checkSubscription = () => {
    if (!user?.isSubscribed) {
      setError("Active subscription required for this action.");
      return false;
    }
    return true;
  };

  const handleLiveContent = async () => {
    if (!validateUrls() || !checkSubscription()) return;
    setIsNewsLoading(true);
    try {
      const { news, sources } = await getLiveNews(targetUrl);
      setNewsResults(news);
      setResult(prev => {
        const base = prev || { battlecard: {} as any, killScript: {} as any, sources: [] };
        return { ...base, news, sources: [...base.sources, ...sources] };
      });
      setActiveModal('live-content');
    } catch (err: any) {
      setError("Failed to fetch live news.");
    } finally {
      setIsNewsLoading(false);
    }
  };

  const handleKillScripts = async () => {
    if (!validateUrls() || !checkSubscription()) return;
    setIsKillScriptsLoading(true);
    try {
      const { rebuttals, sources } = await getTacticalRebuttals(targetUrl, homeUrl, industry);
      setTacticalRebuttals(rebuttals);
      setResult(prev => {
        const base = prev || { battlecard: {} as any, killScript: {} as any, sources: [] };
        return { ...base, rebuttals, sources: [...base.sources, ...sources] };
      });
      setActiveModal('cheat-sheet');
    } catch (err: any) {
      setError("Failed to generate cheat sheet.");
    } finally {
      setIsKillScriptsLoading(false);
    }
  };

  const handleInstantBattlecard = async () => {
    if (!validateUrls() || !checkSubscription()) return;
    
    if (user?.licenseKey) {
      setIsVerifyingLicense(true);
      const isValid = await verifyLicenseAPI(user.licenseKey);
      setIsVerifyingLicense(false);
      
      if (!isValid) {
        setUser(prev => prev ? { ...prev, isSubscribed: false } : null);
        localStorage.removeItem('DR_LICENSE_KEY');
        setError("Your license key has expired or is invalid. Please upgrade.");
        return;
      }
    }

    setIsBattlecardLoading(true);
    try {
      const data = await performDeepScan(targetUrl, homeUrl, industry);
      setResult(data);
      setActiveModal('battlecard');
    } catch (err: any) {
      setError(err.message || 'Deep Scan failed.');
    } finally {
      setIsBattlecardLoading(false);
    }
  };

  const handleReset = () => {
    setStatus('idle');
    setResult(null);
    setError(null);
    setNewsResults(null);
    setTacticalRebuttals(null);
    setTargetUrl('');
    setHomeUrl('');
    setActiveView('landing');
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifyingLicense(true);
    
    let isPro = false;
    if (redeemCode.trim()) {
      isPro = await verifyLicenseAPI(redeemCode);
    }

    if (isPro) {
      localStorage.setItem('DR_LICENSE_KEY', redeemCode);
    }

    setUser({ 
      name: 'Deep Elite', 
      credits: isPro ? 'Unlimited' : 0, 
      tier: isPro ? 'Lifetime Pro' : 'Standard',
      isSubscribed: isPro,
      licenseKey: isPro ? redeemCode : undefined
    });
    
    setIsVerifyingLicense(false);
    setRedeemCode('');
    setActiveModal('none');
    if (isPro) setActiveView('dashboard');
  };

  const handleSignOut = () => {
    localStorage.removeItem('DR_LICENSE_KEY');
    setUser(null);
    setShowProfileDropdown(false);
    handleReset();
  };

  const handleUpgradeClick = () => {
    window.open(LS_CHECKOUT_URL, '_blank', 'noopener,noreferrer');
  };

  const copyDebugUrl = () => {
    navigator.clipboard.writeText(LS_CHECKOUT_URL);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#020617] text-slate-200 selection:bg-brand-500/30">
      {/* SaaS Navigation */}
      <nav className="glass sticky top-0 z-50 border-b border-slate-800/50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setActiveView('landing')}>
            <div className="bg-gradient-to-br from-brand-500 to-indigo-600 p-2 rounded-xl shadow-lg shadow-brand-500/20 group-hover:scale-110 transition-transform">
                <Search className="w-5 h-5 text-white" />
            </div>
            <span className="font-black text-2xl tracking-tighter text-white uppercase italic">
              DEEP<span className="text-brand-500">RESEARCH</span>
            </span>
          </div>
          
          <div className="hidden lg:flex items-center space-x-8 text-sm font-semibold text-slate-400">
            {user?.isSubscribed && (
              <button 
                onClick={() => { setActiveView('dashboard'); setActiveModal('none'); }} 
                className={`hover:text-brand-400 transition-colors ${activeView === 'dashboard' ? 'text-brand-400' : ''}`}
              >
                Dashboard
              </button>
            )}
            <button 
              onClick={() => { setActiveView('roadmap'); setActiveModal('none'); }} 
              className={`flex items-center gap-2 hover:text-brand-400 transition-colors ${activeView === 'roadmap' ? 'text-brand-400' : ''}`}
            >
              <Map className="w-4 h-4" />
              Roadmap
            </button>
            <button onClick={() => setActiveModal('about')} className="hover:text-brand-400 transition-colors">About</button>
            
            <div className="h-4 w-px bg-slate-800"></div>
            
            {user?.isSubscribed ? (
              <div className="relative" ref={dropdownRef}>
                <button 
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                  className="flex items-center gap-3 text-white bg-slate-800/50 hover:bg-slate-800 px-4 py-2 rounded-xl border border-slate-700/50 transition-all"
                >
                  <div className={`w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center text-[10px] font-bold text-slate-900 shadow-lg`}>
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <span className="text-sm">{user.name}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${showProfileDropdown ? 'rotate-180' : ''}`} />
                </button>

                {showProfileDropdown && (
                  <div className="absolute right-0 mt-2 w-64 glass border border-slate-700 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                    <div className="p-4 border-b border-slate-800">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Account Info</p>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-slate-300">Status</span>
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20`}>
                           Pro Active
                        </span>
                      </div>
                    </div>
                    <div className="p-2 border-t border-slate-800">
                      <button 
                        onClick={handleSignOut}
                        className="w-full flex items-center gap-3 px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button 
                onClick={() => setActiveModal('signin')}
                className="bg-brand-600 hover:bg-brand-500 text-white px-6 py-2.5 rounded-xl transition-all font-bold shadow-lg shadow-brand-600/20"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </nav>

      <main className="flex-1">
        {activeView === 'roadmap' ? (
          <div className="container mx-auto px-4 py-12">
            <RoadmapView onBack={() => setActiveView(user?.isSubscribed ? 'dashboard' : 'landing')} />
          </div>
        ) : activeView === 'landing' ? (
          <LandingView 
            onGetStarted={() => user?.isSubscribed ? setActiveView('dashboard') : setActiveModal('signin')} 
            onUpgrade={handleUpgradeClick} 
            showDebug={showCheckoutDebug}
            setShowDebug={setShowCheckoutDebug}
            debugUrl={LS_CHECKOUT_URL}
            onCopyDebug={copyDebugUrl}
          />
        ) : (
          <div className="container mx-auto px-4 py-12 max-w-5xl animate-in fade-in zoom-in duration-700">
            {status === 'scanning' ? (
              <LoadingOverlay />
            ) : (
              <>
                 <div className="mb-16 text-center">
                    <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-bold uppercase tracking-widest mb-6">
                      <Sparkles className="w-3 h-3 fill-current" />
                      Gemini 3 Pro Intelligence Enabled
                    </span>
                    <Scanner 
                      onScan={(t, h, i) => { setTargetUrl(t); setHomeUrl(h); setIndustry(i); handleInstantBattlecard(); }} 
                      isLoading={isBattlecardLoading || isVerifyingLicense}
                      onUpdate={(t, h, i) => { setTargetUrl(t); setHomeUrl(h); setIndustry(i); }}
                      initialValues={{ target: targetUrl, home: homeUrl, industry }}
                      isSubscribed={!!user?.isSubscribed}
                    />
                    
                    {error && (
                      <div className="mt-4 p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-400 text-sm flex flex-col items-center justify-center gap-3 max-w-lg mx-auto">
                        <div className="flex items-center gap-2">
                          <AlertCircle className="w-4 h-4" />
                          {error}
                        </div>
                      </div>
                    )}
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
                   <HeroFeature 
                     icon={<Globe className="w-6 h-6 text-brand-400" />}
                     title="Live Web Content" 
                     description="Scans the web right now for news the competitor just released."
                     onAction={handleLiveContent}
                     isLoading={isNewsLoading}
                     valueProp="Catch pricing changes the moment they happen."
                   />
                   <HeroFeature 
                     icon={<Shield className="w-6 h-6 text-indigo-400" />}
                     title="Kill Scripts" 
                     description="Generates exact rebuttals to pivot from rivals to your advantages."
                     onAction={handleKillScripts}
                     isLoading={isKillScriptsLoading}
                     valueProp="Turn 'too expensive' into a reason to buy from you."
                   />
                   <HeroFeature 
                     icon={<Zap className="w-6 h-6 text-amber-400" />}
                     title="Instant Battlecard" 
                     description="A head-to-head comparison report for deep strategic advantage."
                     onAction={handleInstantBattlecard}
                     isLoading={isBattlecardLoading}
                     valueProp="Board-ready executive reports in seconds."
                   />
                 </div>

                 {result && (
                   <div className="mt-20 border-t border-slate-800 pt-12 text-center">
                      <button 
                        onClick={() => setActiveModal('battlecard')}
                        className="inline-flex items-center gap-2 text-brand-400 hover:text-white transition-colors text-sm font-bold group"
                      >
                        <Book className="w-4 h-4" />
                        View Latest Scan
                        <TrendingUp className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                      </button>
                   </div>
                 )}
              </>
            )}
          </div>
        )}
      </main>

      {/* Global Modals */}
      <Modal isOpen={activeModal === 'checkout-success'} onClose={() => setActiveModal('none')} title="Success! Activation Required">
        <div className="text-center space-y-8 py-4">
          <div className="w-24 h-24 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto text-emerald-400 border-4 border-emerald-500/30 animate-bounce">
            <PartyPopper className="w-12 h-12" />
          </div>
          <div className="space-y-3">
            <h2 className="text-3xl font-black text-white tracking-tight">Purchase Complete!</h2>
            <p className="text-slate-400">Please paste your Lemon Squeezy license key below to activate your account for life.</p>
          </div>
          <form className="space-y-4 text-left" onSubmit={handleSignIn}>
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Your License Key</label>
              <input 
                type="text" 
                value={redeemCode}
                onChange={(e) => setRedeemCode(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-white outline-none focus:border-emerald-500 transition-all font-mono" 
                placeholder="LS-XXXX-XXXX-XXXX" 
                required
              />
            </div>
            <button type="submit" disabled={isVerifyingLicense} className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all">
              {isVerifyingLicense ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-current" />}
              {isVerifyingLicense ? 'Activating...' : 'Activate Lifetime Access'}
            </button>
          </form>
        </div>
      </Modal>

      <Modal isOpen={activeModal === 'signin'} onClose={() => setActiveModal('none')} title="License Verification">
        <form className="space-y-6" onSubmit={handleSignIn}>
          <div className="text-center mb-4">
            <p className="text-slate-400 text-sm">Enter your Lemon Squeezy license key to unlock Pro features.</p>
          </div>
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">License Key</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-400" />
                <input 
                  type="text" 
                  value={redeemCode}
                  onChange={(e) => setRedeemCode(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-12 pr-4 py-3 text-white outline-none focus:border-brand-500 font-mono" 
                  placeholder="DEEP-XXXX-XXXX" 
                />
              </div>
              <p className="text-[10px] text-slate-500 italic mt-1">Found in your Lemon Squeezy receipt email.</p>
            </div>
            <button type="submit" disabled={isVerifyingLicense} className="w-full py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all">
              {isVerifyingLicense ? <Loader2 className="w-5 h-5 animate-spin" /> : <Shield className="w-5 h-5" />}
              {isVerifyingLicense ? 'Verifying...' : 'Authenticate & Unlock'}
            </button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={activeModal === 'privacy'} onClose={() => setActiveModal('none')} title="Privacy Policy">
        <div className="space-y-4 text-slate-300 text-sm leading-relaxed">
          <h4 className="text-white font-bold">1. Data Collection</h4>
          <p>DeepResearch AI collects URL data provided by the user to perform competitive analysis. We use Google Search Grounding to fetch publicly available information about these URLs.</p>
          <h4 className="text-white font-bold">2. License Verification</h4>
          <p>We verify license keys through Lemon Squeezy. No payment information is stored on our servers; all transactions are handled securely by our payment processor.</p>
          <h4 className="text-white font-bold">3. Data Usage</h4>
          <p>Analyzed data is used solely to generate the reports shown in your dashboard. We do not sell user data to third parties.</p>
          <h4 className="text-white font-bold">4. Cookies</h4>
          <p>We use local storage and essential cookies to maintain your session and license activation status. We do not use tracking cookies for marketing.</p>
        </div>
      </Modal>

      <Modal isOpen={activeModal === 'terms'} onClose={() => setActiveModal('none')} title="Terms of Service">
        <div className="space-y-4 text-slate-300 text-sm leading-relaxed">
          <h4 className="text-white font-bold">1. Service Usage</h4>
          <p>By using DeepResearch AI, you agree to use the tool for professional competitive intelligence purposes only. You must not use the tool to scan illegal or harmful content.</p>
          <h4 className="text-white font-bold">2. License Terms</h4>
          <p>Each license is for individual use. Redistribution or resale of intelligence reports generated by the tool for commercial gain without a partner agreement is prohibited.</p>
          <h4 className="text-white font-bold">3. Limitation of Liability</h4>
          <p>DeepResearch AI provides intelligence based on public web data and AI reasoning. We do not guarantee the 100% accuracy of competitive data and are not liable for business decisions made based on reports.</p>
        </div>
      </Modal>

      <Modal isOpen={activeModal === 'about'} onClose={() => setActiveModal('none')} title="Founder's Note">
        <div className="space-y-4 text-slate-300 text-sm">
          <p>I built DeepResearch because competitive advantage shouldn't take hours of manual work. We leverage the world's most capable reasoning models to dismantle rival strategies in seconds.</p>
          <p className="font-bold text-white">Tsepo Motsatse<br/>Founder, DeepResearch</p>
        </div>
      </Modal>

      <Modal isOpen={activeModal === 'battlecard'} onClose={() => setActiveModal('none')} title="Full Intel Report">
        {result && <ResultsView result={result} />}
      </Modal>

      <Modal isOpen={activeModal === 'live-content'} onClose={() => setActiveModal('none')} title="Real-Time Pulse Check">
        <div className="space-y-6">
          <div className="bg-emerald-500/10 p-4 rounded-xl border border-emerald-500/20">
            <h4 className="text-emerald-400 font-bold flex items-center gap-2 text-sm">
              <Globe className="w-5 h-5" />
              Latest Scan: {targetUrl}
            </h4>
          </div>
          {newsResults?.map((item, i) => (
            <div key={i} className="glass p-5 rounded-2xl border-slate-800 space-y-2">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{item.date || "Recent"}</span>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-brand-400"><ExternalLink className="w-4 h-4" /></a>
              </div>
              <h5 className="text-white font-bold leading-tight">{item.title}</h5>
              <p className="text-slate-400 text-sm">{item.snippet}</p>
            </div>
          ))}
          <button onClick={() => setActiveModal('none')} className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold">Back</button>
        </div>
      </Modal>

      <Modal isOpen={activeModal === 'cheat-sheet'} onClose={() => setActiveModal('none')} title="Tactical Sales Cheat Sheet">
        <div className="space-y-6">
          <div className="bg-brand-500/10 p-4 rounded-xl border border-brand-500/20 text-brand-400 font-bold text-sm">
            Winning Tactics for {targetUrl}
          </div>
          {tacticalRebuttals?.map((item, i) => (
            <div key={i} className="glass p-5 rounded-2xl border-slate-800 space-y-3">
              <p className="text-xs font-bold text-slate-500 uppercase">Objection: <span className="text-slate-200 italic font-medium normal-case">"{item.objection}"</span></p>
              <p className="text-brand-300 text-sm font-bold pl-4 border-l-2 border-brand-500/30">"{item.rebuttal}"</p>
            </div>
          ))}
          <button onClick={() => setActiveModal('none')} className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold">Back</button>
        </div>
      </Modal>

      {/* Footer */}
      <footer className="border-t border-slate-800/50 bg-[#01040f] py-16 px-6 mt-auto">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <Search className="w-6 h-6 text-brand-400" />
              <span className="font-black text-white text-xl tracking-tight uppercase">DeepResearch AI</span>
            </div>
            <p className="text-slate-500 text-sm max-w-xs leading-relaxed">
              The world's most advanced AI-driven competitive intelligence platform for high-growth sales teams. Win every call with live web data.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-6">
              <h5 className="text-white font-bold text-sm uppercase tracking-widest">Product</h5>
              <ul className="space-y-3 text-slate-500 text-xs font-bold">
                <li><button onClick={() => setActiveView('landing')} className="hover:text-brand-400 transition-colors">Home</button></li>
                <li><button onClick={() => setActiveView('roadmap')} className="hover:text-brand-400 transition-colors">Roadmap</button></li>
                <li><button onClick={() => setActiveModal('about')} className="hover:text-brand-400 transition-colors">About Us</button></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h5 className="text-white font-bold text-sm uppercase tracking-widest">Legal</h5>
              <ul className="space-y-3 text-slate-500 text-xs font-bold">
                <li><button onClick={() => setActiveModal('privacy')} className="hover:text-brand-400 transition-colors">Privacy Policy</button></li>
                <li><button onClick={() => setActiveModal('terms')} className="hover:text-brand-400 transition-colors">Terms of Service</button></li>
                <li><a href={`mailto:${SUPPORT_EMAIL}`} className="hover:text-brand-400 transition-colors flex items-center gap-2">Contact Support <ExternalLink className="w-3 h-3" /></a></li>
              </ul>
            </div>
          </div>

          <div className="space-y-6 md:text-right">
             <div className="flex md:justify-end gap-4">
               <a href="#" className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl hover:text-brand-400 hover:border-brand-500/50 transition-all"><Twitter className="w-5 h-5" /></a>
               <a href="#" className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl hover:text-brand-400 hover:border-brand-500/50 transition-all"><Linkedin className="w-5 h-5" /></a>
             </div>
             <p className="text-slate-600 text-[10px] uppercase font-black tracking-[0.2em]">© 2025 DeepResearch AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

const LandingView = ({ 
  onGetStarted, 
  onUpgrade, 
  showDebug, 
  setShowDebug, 
  debugUrl,
  onCopyDebug
}: { 
  onGetStarted: () => void, 
  onUpgrade: () => void, 
  showDebug: boolean, 
  setShowDebug: (v: boolean) => void,
  debugUrl: string,
  onCopyDebug: () => void
}) => (
  <div className="animate-in fade-in duration-1000">
    {/* Hero Section */}
    <section className="relative pt-32 pb-40 px-6 overflow-hidden text-center">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-6xl h-full pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-500/10 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-[120px] animate-pulse-slow delay-700"></div>
      </div>

      <div className="container mx-auto max-w-5xl relative z-10">
        <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-black uppercase tracking-widest mb-10">
          <Sparkles className="w-4 h-4" />
          The Intelligence Layer for Sales
        </span>
        <h1 className="text-6xl md:text-9xl font-black text-white mb-8 tracking-tighter leading-[0.85]">
          AI Competitive <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-indigo-500 italic">Intelligence</span> <br/>
          for Sales Teams
        </h1>
        <p className="text-slate-400 text-xl md:text-2xl max-w-2xl mx-auto mb-14 leading-relaxed">
          The ultimate engine for dismantling rivals with live data. Instantly generate battlecards and kill scripts designed to win high-stakes sales conversations.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <button 
            onClick={onGetStarted}
            className="w-full sm:w-auto px-14 py-6 bg-brand-600 hover:bg-brand-500 text-white rounded-2xl font-black text-2xl shadow-2xl shadow-brand-600/30 flex items-center justify-center gap-4 transition-all hover:-translate-y-1 active:scale-95"
          >
            Start Analyzing
            <ArrowRight className="w-6 h-6" />
          </button>
          <button 
            onClick={() => {
              const element = document.getElementById('pricing');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-14 py-6 glass border-slate-700 text-slate-300 hover:bg-slate-800 rounded-2xl font-bold text-2xl flex items-center justify-center gap-4 transition-all"
          >
            View Pricing
          </button>
        </div>
      </div>
    </section>

    {/* Trusted By Section */}
    <section className="py-16 border-y border-slate-800/50 bg-slate-950/30">
       <div className="container mx-auto px-6 max-w-6xl text-center">
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.25em] mb-10">Empowering high-performance teams globally</p>
          <div className="flex flex-wrap justify-center items-center gap-16 opacity-30 grayscale contrast-125">
             <div className="flex items-center gap-2 text-white font-black text-2xl tracking-tighter">
               <Zap className="w-7 h-7 text-brand-400" /> VORTEX
             </div>
             <div className="flex items-center gap-2 text-white font-black text-2xl tracking-tighter">
               <Globe className="w-7 h-7 text-indigo-400" /> NEXUS
             </div>
             <div className="flex items-center gap-2 text-white font-black text-2xl tracking-tighter">
               <Shield className="w-7 h-7 text-emerald-400" /> SENTINEL
             </div>
             <div className="flex items-center gap-2 text-white font-black text-2xl tracking-tighter">
               <Target className="w-7 h-7 text-rose-400" /> VECTOR
             </div>
          </div>
       </div>
    </section>

    {/* Feature Grid */}
    <section className="py-32 px-6 bg-[#01040f]">
       <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
             <div className="glass p-12 rounded-[3rem] border-slate-800 space-y-6 group hover:border-brand-500/30 transition-all cursor-default">
                <div className="w-16 h-16 bg-brand-500/10 rounded-2xl flex items-center justify-center text-brand-400 group-hover:scale-110 transition-transform shadow-inner shadow-brand-500/20">
                  <Globe className="w-9 h-9" />
                </div>
                <h3 className="text-3xl font-black text-white tracking-tight">Live Crawling</h3>
                <p className="text-slate-500 leading-relaxed text-lg">Real-time scans for press releases, blog updates, and pricing pivots. Never be blindsided on a call again.</p>
             </div>
             <div className="glass p-12 rounded-[3rem] border-slate-800 space-y-6 group hover:border-indigo-500/30 transition-all cursor-default">
                <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform shadow-inner shadow-indigo-500/20">
                  <Layout className="w-9 h-9" />
                </div>
                <h3 className="text-3xl font-black text-white tracking-tight">Battlecards</h3>
                <p className="text-slate-500 leading-relaxed text-lg">Dynamic feature matrices comparing your strengths vs rival vulnerabilities with boardroom-ready precision.</p>
             </div>
             <div className="glass p-12 rounded-[3rem] border-slate-800 space-y-6 group hover:border-emerald-500/30 transition-all cursor-default">
                <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform shadow-inner shadow-emerald-500/20">
                  <MessageCircle className="w-9 h-9" />
                </div>
                <h3 className="text-3xl font-black text-white tracking-tight">Kill Scripts</h3>
                <p className="text-slate-500 leading-relaxed text-lg">Conversational rebuttals generated specifically for your industry to pivot from price to value instantly.</p>
             </div>
          </div>
       </div>
    </section>

    {/* Pricing Section */}
    <section id="pricing" className="py-40 px-6">
      <div className="container mx-auto max-w-4xl text-center space-y-20">
        <div className="space-y-6">
          <h2 className="text-5xl md:text-7xl font-black text-white tracking-tight leading-none">The Lifetime <br/> <span className="text-brand-400 italic">Strategic Edge</span></h2>
          <p className="text-slate-500 max-w-xl mx-auto text-xl">One single investment to secure your team's competitive dominance for life.</p>
        </div>

        <div className="glass p-2 pb-20 rounded-[5rem] border-brand-500/30 relative shadow-2xl shadow-brand-500/10 bg-gradient-to-b from-slate-900/50 to-slate-950/80">
          <div className="absolute top-0 right-14 -translate-y-1/2 bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 px-8 py-3 rounded-full font-black text-sm uppercase tracking-widest shadow-2xl">LIMITED TIME OFFER</div>
          <div className="p-20 space-y-16">
            <div className="space-y-6">
              <h3 className="text-3xl font-black text-slate-200 uppercase tracking-widest">Lifetime Pro License</h3>
              <div className="flex items-center justify-center gap-3">
                <span className="text-9xl font-black text-white leading-none">$99</span>
                <div className="text-left">
                  <span className="block text-slate-500 font-bold uppercase text-xs tracking-tighter line-through">$499</span>
                  <span className="block text-emerald-400 font-black uppercase text-lg leading-none">LIFETIME</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-left max-w-3xl mx-auto">
              {[
                "Unlimited Competitor Scans",
                "Gemini 3 Pro Intelligence",
                "Live Web Search Grounding",
                "Board-Ready Intel Reports",
                "Tactical Sales Kill Scripts",
                "Future Roadmap Access"
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-4 text-slate-300 text-lg font-medium">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 text-emerald-400" />
                  </div>
                  {feature}
                </div>
              ))}
            </div>

            <div className="space-y-10">
              <button 
                onClick={onUpgrade}
                className="group relative px-20 py-8 bg-brand-600 hover:bg-brand-500 text-white rounded-3xl font-black text-3xl shadow-2xl shadow-brand-600/40 transition-all transform hover:-translate-y-2 active:scale-95 overflow-hidden"
              >
                <span className="relative z-10 flex items-center gap-4">
                  Buy Now
                  <ArrowRight className="w-8 h-8 group-hover:translate-x-2 transition-transform" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </button>
              
              <div className="flex flex-col items-center gap-6">
                <div className="flex items-center gap-8 opacity-70">
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-black uppercase tracking-widest">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" /> SECURE CHECKOUT
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-black uppercase tracking-widest">
                    <PartyPopper className="w-5 h-5 text-brand-400" /> INSTANT ACTIVATION
                  </div>
                </div>
                
                <button 
                  onClick={() => setShowDebug(!showDebug)}
                  className="text-xs text-slate-600 hover:text-slate-400 transition-colors uppercase font-black tracking-widest flex items-center gap-2"
                >
                  <Bug className="w-4 h-4" /> Link not working?
                </button>
              </div>

              {showDebug && (
                <div className="mt-10 p-8 bg-slate-900/80 border border-slate-800 rounded-[3rem] text-left animate-in slide-in-from-top-6 duration-700">
                  <p className="text-xs text-slate-500 font-black uppercase tracking-widest mb-4">Manual Checkout Link</p>
                  <p className="text-sm text-slate-400 mb-6 leading-relaxed">If your browser is blocking popups, copy and paste this URL manually to complete your purchase:</p>
                  <div className="flex items-center gap-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <code className="text-xs text-brand-400 flex-1 truncate font-mono">{debugUrl}</code>
                    <button 
                      onClick={onCopyDebug}
                      className="p-3 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
                      title="Copy Link"
                    >
                      <Copy className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex justify-center gap-8 opacity-30 items-center">
               <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-6" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-8" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" className="h-6" />
            </div>
            <p className="text-slate-600 text-xs font-black uppercase tracking-[0.3em]">Official Storefront on Lemon Squeezy</p>
          </div>
        </div>
      </div>
    </section>
  </div>
);

const HeroFeature = ({ 
  icon, title, description, onAction, isLoading, valueProp 
}: { 
  icon: React.ReactNode; title: string; description: string; onAction?: () => void; isLoading?: boolean; valueProp?: string;
}) => (
  <div onClick={isLoading ? undefined : onAction} className="glass p-10 rounded-[3rem] border-slate-800 hover:border-brand-500/40 transition-all group cursor-pointer relative overflow-hidden flex flex-col h-full">
    {isLoading && (
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md z-20 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-brand-400 animate-spin" />
      </div>
    )}
    <div className="bg-slate-900/50 w-14 h-14 rounded-2xl flex items-center justify-center mb-8 border border-slate-700/50 group-hover:scale-110 transition-transform shadow-lg shadow-black/20">
        {icon}
    </div>
    <h3 className="text-2xl font-black text-white mb-4 group-hover:text-brand-400 transition-colors tracking-tight">{title}</h3>
    <p className="text-slate-500 text-base leading-relaxed mb-8 flex-grow">{description}</p>
    <div className="mt-auto pt-8 border-t border-slate-800/50">
      <p className="text-[10px] text-brand-400 uppercase font-black tracking-widest mb-2">PRO Intelligence</p>
      <p className="text-slate-300 text-sm font-medium italic leading-relaxed">"{valueProp}"</p>
    </div>
  </div>
);

export default App;
