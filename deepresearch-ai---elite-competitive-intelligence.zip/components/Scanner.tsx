
import React, { useEffect } from 'react';
import { Search, Globe, Zap, Target, Briefcase, Lock, AlertCircle } from 'lucide-react';

interface ScannerProps {
  onScan: (targetUrl: string, homeUrl: string, industry: string) => void;
  isLoading: boolean;
  onUpdate: (targetUrl: string, homeUrl: string, industry: string) => void;
  initialValues: { target: string; home: string; industry: string };
  isSubscribed: boolean;
}

const INDUSTRIES = [
  "SaaS / Software",
  "Fintech",
  "EdTech",
  "HealthTech",
  "E-commerce",
  "Cybersecurity",
  "Artificial Intelligence",
  "Agency / Services",
  "CRM / Sales",
  "Productivity / SaaS",
  "Fintech / Payments"
];

export const Scanner: React.FC<ScannerProps> = ({ onScan, isLoading, onUpdate, initialValues, isSubscribed }) => {
  const [targetUrl, setTargetUrl] = React.useState(initialValues.target);
  const [homeUrl, setHomeUrl] = React.useState(initialValues.home);
  const [industry, setIndustry] = React.useState(initialValues.industry);

  useEffect(() => {
    setTargetUrl(initialValues.target);
    setHomeUrl(initialValues.home);
    setIndustry(initialValues.industry);
  }, [initialValues]);

  useEffect(() => {
    onUpdate(targetUrl, homeUrl, industry);
  }, [targetUrl, homeUrl, industry]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubscribed && targetUrl.trim() && homeUrl.trim()) {
      onScan(targetUrl.trim(), homeUrl.trim(), industry);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-4xl md:text-6xl font-black mb-6 bg-gradient-to-r from-brand-400 via-indigo-400 to-brand-500 bg-clip-text text-transparent leading-[1.2] py-2">
          Intelligence at Scale
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          DeepResearch AI scans the live web to dismantle your competition. 
        </p>
      </div>

      {!isSubscribed && (
        <div className="max-w-3xl mx-auto mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-center gap-3 text-amber-400 animate-pulse">
          <Lock className="w-5 h-5" />
          <span className="text-sm font-bold uppercase tracking-wider">Inactive Subscription: Upgrade to Unlock Deep Scanning</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className={`space-y-4 max-w-3xl mx-auto transition-opacity ${!isSubscribed ? 'opacity-50 grayscale-[0.5]' : ''}`}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
          <div className="glass p-3 rounded-2xl border border-slate-700/50 flex items-center space-x-3 focus-within:border-brand-500/50 transition-colors">
            <Globe className="w-5 h-5 text-emerald-400" />
            <div className="flex-1">
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-widest">Your URL</label>
              <input
                type="url"
                placeholder="https://yourcompany.com"
                value={homeUrl}
                onChange={(e) => setHomeUrl(e.target.value)}
                disabled={isLoading || !isSubscribed}
                className="w-full bg-transparent border-none text-sm focus:ring-0 placeholder:text-slate-600 text-slate-100 p-0"
                required
              />
            </div>
          </div>
          
          <div className="glass p-3 rounded-2xl border border-slate-700/50 flex items-center space-x-3 focus-within:border-brand-500/50 transition-colors">
            <Target className="w-5 h-5 text-rose-400" />
            <div className="flex-1">
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-widest">Competitor URL</label>
              <input
                type="url"
                placeholder="https://competitor.com"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                disabled={isLoading || !isSubscribed}
                className="w-full bg-transparent border-none text-sm focus:ring-0 placeholder:text-slate-600 text-slate-100 p-0"
                required
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 glass p-3 rounded-2xl border border-slate-700/50 flex items-center space-x-3 focus-within:border-brand-500/50 transition-colors text-left">
            <Briefcase className="w-5 h-5 text-brand-400" />
            <div className="flex-1">
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-widest">Industry Context</label>
              <select
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                disabled={isLoading || !isSubscribed}
                className="w-full bg-transparent border-none text-sm focus:ring-0 text-slate-100 p-0 cursor-pointer appearance-none"
              >
                {INDUSTRIES.map(i => <option key={i} value={i} className="bg-slate-900">{i}</option>)}
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !targetUrl || !homeUrl || !isSubscribed}
            className={`flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-bold transition-all shadow-lg md:min-w-[200px] ${
              isLoading || !targetUrl || !homeUrl || !isSubscribed
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-brand-600 hover:bg-brand-500 text-white hover:scale-[1.02] active:scale-95'
            }`}
          >
            {isLoading ? (
              <Zap className="w-5 h-5 animate-spin" />
            ) : !isSubscribed ? (
              <Lock className="w-5 h-5" />
            ) : (
              <Search className="w-5 h-5" />
            )}
            {isLoading ? 'Scanning...' : !isSubscribed ? 'Locked' : 'Deep Research'}
          </button>
        </div>
      </form>
    </div>
  );
};
